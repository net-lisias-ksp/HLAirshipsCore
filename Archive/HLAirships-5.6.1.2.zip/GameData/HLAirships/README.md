# HLAirships Unofficial

Mod for KSP that adds lighter than air parts - unofficial fork by Lisias


## In a Hurry

* [Latest Release](https://github.com/net-lisias-kspu/HLAirships/releases)
* [Source](https://github.com/net-lisias-kspu/HLAirships)
* [Binaries](https://github.com/net-lisias-kspu/HLAirships/tree/Archive)
* [Change Log](./CHANGE_LOG.md)


## Description


## UPSTREAM

* [JewelShisen](https://forum.kerbalspaceprogram.com/index.php?/profile/71737-jewelshisen/):
	+ [Forum](https://forum.kerbalspaceprogram.com/index.php?/topic/49443-airships-in-13-hooliganlabs-mods/&)
	+ [SpaceDock](https://spacedock.info/mod/638/Hooligan%20Labs%20Airships)
* [dunclaw](https://forum.kerbalspaceprogram.com/index.php?/profile/151301-dunclaw/)
 	+ [GitHub](https://github.com/dunclaw/HLAirships)
* [Hooligan Labs](https://forum.kerbalspaceprogram.com/index.php?/profile/45359-hooligan-labs/)
	+ [G+](https://plus.google.com/+HooliganlabsPlus)
	+ [Wikia](http://hlmods.wikia.com/wiki/Hooligan_Labs_Kerbal_Space_Program_Mods)
	+ [HomePage](https://hooliganlabs.com)
	+ [Web Archive](https://archive.org/details/HooliganLabsAirships-3.0.0)
		- Licensed under the MIT License. 
	+ [Twitter](https://twitter.com/hooliganlabs?lang=en)
* [Kerbas-ad-astra](https://github.com/Kerbas-ad-astra)'s fork
	+ [LibreLabsAirships](https://github.com/Kerbas-ad-astra/LibreLabsAirships) 
